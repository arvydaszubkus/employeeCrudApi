import React, { useState, useEffect } from "react";

function EmployeeForm({ onSubmit, employeeToEdit, clearEdit }) {
  const [employee, setEmployee] = useState({
    name: "",
    email: "",
    jobTitle: "",
  });

  useEffect(() => {
    if (employeeToEdit) {
      setEmployee(employeeToEdit);
    }
  }, [employeeToEdit]);

  const handleChange = (e) => {
    setEmployee({ ...employee, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(employee);
    setEmployee({ name: "", email: "", jobTitle: "" });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        name="name"
        placeholder="Name"
        value={employee.name}
        onChange={handleChange}
        required
      />
      <input
        name="email"
        type="email"
        placeholder="Email"
        value={employee.email}
        onChange={handleChange}
        required
      />
      <input
        name="jobTitle"
        placeholder="Job Title"
        value={employee.jobTitle}
        onChange={handleChange}
        required
      />
      <div style={{ display: "flex", gap: "10px" }}>
        <button type="submit">
          {employeeToEdit ? "Update Employee" : "Add Employee"}
        </button>
        {employeeToEdit && (
          <button type="button" className="cancel" onClick={clearEdit}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}

export default EmployeeForm;
