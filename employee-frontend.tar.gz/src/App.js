import React, { useState, useEffect } from "react";
import {
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee,
} from "./services/EmployeeService";

import EmployeeForm from "./components/EmployeeForm";
import EmployeeList from "./components/EmployeeList";

import "./App.css"; // Import the CSS

function App() {
  const [employees, setEmployees] = useState([]);
  const [editingEmployee, setEditingEmployee] = useState(null);

  const fetchEmployees = () => {
    getEmployees().then((res) => setEmployees(res.data));
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleAdd = (employee) => {
    createEmployee(employee).then(fetchEmployees);
  };

  const handleUpdate = (employee) => {
    updateEmployee(employee.id, employee).then(() => {
      setEditingEmployee(null);
      fetchEmployees();
    });
  };

  const handleDelete = (id) => {
    deleteEmployee(id).then(fetchEmployees);
  };

  const handleSubmit = (employee) => {
    if (editingEmployee) {
      handleUpdate(employee);
    } else {
      handleAdd(employee);
    }
  };

  const handleEdit = (employee) => {
    setEditingEmployee(employee);
  };

  const clearEdit = () => {
    setEditingEmployee(null);
  };

  return (
    <div className="container">
      <h1>Employee CRUD App</h1>
      <EmployeeForm
        onSubmit={handleSubmit}
        employeeToEdit={editingEmployee}
        clearEdit={clearEdit}
      />
      <EmployeeList
        employees={employees}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
    </div>
  );
}

export default App;
